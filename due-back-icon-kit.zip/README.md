# Due Back: app icon and loading screen

## Files

assets/
- `icon.png` (1024×1024, full-bleed square): main app icon (iOS and legacy Android).
- `adaptive-icon-foreground.png` (1024×1024, transparent): Android adaptive icon
  foreground. The mark sits inside the 66/108 safe zone, so every launcher mask
  (circle, squircle, rounded square) keeps the whole book and ribbon.
- `adaptive-icon-monochrome.png` (1024×1024, white on transparent): Android 13+
  themed icon. The system tints it to match the wallpaper.
- `splash-icon.png` (1024×1024, transparent): native splash image.
- `play-store-icon.png` (512×512, full-bleed): upload in the Play Console store
  listing. Google applies its own rounding, so don't round it.

svg/: editable sources for all of the above.

src/LoadingScreen.tsx: the in-app loading screen (mark + "Due Back" +
"AUDIOBOOK LIBRARY"), which takes over seamlessly from the native splash.

preview-masks.png: the adaptive icon under circle, squircle and rounded-square
masks. The dashed red circle is the safe zone.

Colours: background #1B1410, amber #E8A23A, paper #EFE3CC, ribbon #C8402F.

## app.json

```json
{
  "expo": {
    "icon": "./assets/icon.png",
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon-foreground.png",
        "monochromeImage": "./assets/adaptive-icon-monochrome.png",
        "backgroundColor": "#1B1410"
      }
    },
    "plugins": [
      ["expo-splash-screen", {
        "image": "./assets/splash-icon.png",
        "imageWidth": 200,
        "resizeMode": "contain",
        "backgroundColor": "#1B1410"
      }]
    ]
  }
}
```

Merge these keys into the existing config; don't replace other plugin entries.

## Why the splash is the icon only

Since Android 12 the system splash shows only a centred icon on a solid
colour; it can't show the wordmark. So:

1. The native splash shows the book on #1B1410 while the app starts.
2. LoadingScreen.tsx renders the same image at the same size and position, so
   the switch is invisible. The mark then eases up and the wordmark fades in.
3. When fonts, the database and the restored player state are ready (and at
   least 0.9 s has passed), it fades out.

Icon and splash changes are native config: they need a rebuild.
